#pragma once
#include <opxy/effect.hpp>

namespace septet {
// At most opxy::effect_state_bytes; storage starts zeroed and is never destroyed.
struct State { opxy::i32 reserved; };
void initialize(State& state);
void process(State& state, opxy::Channel left, opxy::Channel right, opxy::Parameters parameters);
}
